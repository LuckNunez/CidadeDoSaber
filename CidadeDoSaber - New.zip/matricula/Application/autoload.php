<?php

spl_autoload_register(function ($class) {
    // Remove o namespace global "Application"
    $class = str_replace('Application\\', '', $class);

    // Ajuste o diretório base conforme a estrutura do seu projeto
    $base_dir = __DIR__ . '/Application/';  // Ajuste para a pasta Application

    // Substitui a barra invertida para construir o caminho correto
    $file = $base_dir . str_replace('\\', '/', $class) . '.php';
    
    if (file_exists($file)) {
        require $file;
    } else {
        // Exibe um erro mais informativo com o caminho completo do arquivo
        echo "Erro ao importar a classe: {$class}. Arquivo não encontrado: {$file}";
    }
});
