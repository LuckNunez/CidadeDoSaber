<?php

namespace Application\controllers;

class Address extends \Application\core\Controller
{
    public function index()
    {
        $addressModel = $this->model('Address');

        if (method_exists($addressModel, 'all')) {
            $addresses = $addressModel->all();
            $this->view('address/index', ['addresses' => $addresses]);
        } else {
            // Exibe erro caso o método não exista no modelo
            echo "Erro: Método 'all' não encontrado no modelo 'Address'.";
        }
    }
}
