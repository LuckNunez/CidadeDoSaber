<?php

namespace Application\core;

abstract class Controller
{
    public function model($model)
    {
        $model = "\\Application\\models\\{$model}";
        if (class_exists($model)) {
            return new $model();
        } else {
            throw new \Exception("Modelo '{$model}' não encontrado.");
        }
    }

    public function view($view, $data = [])
    {
        $filePath = "../Application/views/{$view}.php";
        if (file_exists($filePath)) {
            extract($data);
            include $filePath;
        } else {
            echo "Erro: View '{$view}' não encontrada.";
        }
    }
}
