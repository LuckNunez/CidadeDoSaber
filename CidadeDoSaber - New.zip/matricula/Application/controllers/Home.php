<?php

namespace Application\controllers;

class Home extends \Application\core\Controller
{
    public function index()
    {
        $viewPath = 'home/index';
        if (file_exists("../Application/views/{$viewPath}.php")) {
            $this->view($viewPath);
        } else {
            echo "Erro: A view '{$viewPath}' não foi encontrada.";
        }
    }
}
