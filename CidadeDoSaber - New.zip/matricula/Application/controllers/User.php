<?php

namespace Application\controllers;

class User extends \Application\core\Controller
{
    public function save()
    {
        $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
        $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

        if ($email && $password) {
            $userModel = $this->model('User');

            if (method_exists($userModel, 'findByEmail')) {
                $existingUser = $userModel->findByEmail($email);

                if ($existingUser) {
                    echo "Erro: Usuário já cadastrado.";
                    return;
                }

                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $userModel->insert(['email' => $email, 'password' => $hashedPassword]);

                echo "Usuário cadastrado com sucesso!";
            } else {
                echo "Erro: Método 'findByEmail' não encontrado no modelo 'User'.";
            }
        } else {
            echo "Erro: Email ou senha inválidos.";
        }
    }
}
