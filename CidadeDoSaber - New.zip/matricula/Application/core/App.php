<?php

namespace Application\core;



class App
{
    protected $controller = 'Home';
    protected $method = 'index';
    protected $params = [];

    public function __construct()
    {
        $url = $this->parseUrl();

        if (isset($url[0]) && file_exists("../Application/controllers/{$url[0]}.php")) {
            $this->controller = $url[0];
            unset($url[0]);
        }

        $controllerClass = "\\Application\\controllers\\{$this->controller}";
        if (class_exists($controllerClass)) {
            $this->controller = new $controllerClass();
        } else {
            echo "Erro: Controlador '{$this->controller}' não encontrado.";
            return;
        }

        if (isset($url[1]) && method_exists($this->controller, $url[1])) {
            $this->method = $url[1];
            unset($url[1]);
        }

        $this->params = $url ? array_values($url) : [];

        call_user_func_array([$this->controller, $this->method], $this->params);
    }

    private function parseUrl()
    {
        if (isset($_SERVER['REQUEST_URI'])) {
            $url = filter_var(rtrim($_SERVER['REQUEST_URI'], '/'), FILTER_SANITIZE_URL);
            $url = parse_url($url, PHP_URL_PATH); // Processa somente o caminho da URL
            return explode('/', ltrim($url, '/'));
        }
        return [];
    }

    /**
     * Retorna a URL base do projeto.
     * @param string $path Caminho adicional na URL
     * @return string URL completa
     */
    public static function baseUrl(string $path = ''): string
    {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        $scriptName = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));

        $baseUrl = rtrim("{$protocol}://{$host}{$scriptName}", '/');
        return $baseUrl . '/' . ltrim($path, '/');
    }
}
