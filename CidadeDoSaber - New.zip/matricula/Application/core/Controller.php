<?php

namespace Application\core;

/**
 * Esta classe é responsável por instanciar um model e chamar a view correta
 * passando os dados que serão usados.
 */
abstract class Controller
{
    /**
     * Este método é responsável por instanciar um determinado model.
     *
     * @param  string $model O nome do model que será instanciado.
     * @return object Instância do model solicitado.
     * @throws \Exception Caso o model não exista.
     */
    protected function model($model)
    {
        $classe = 'Application\\models\\' . $model;
        if (!class_exists($classe)) {
            throw new \Exception("Model '$classe' não encontrado.");
        }
        return new $classe();
    }

    /**
     * Este método é responsável por chamar uma determinada view (página).
     *
     * @param  string $view A view que será chamada (ou requerida).
     * @param  array $data São os dados que serão exibidos na view.
     * @param  string|null $message Mensagem opcional a ser exibida na view.
     * @return void
     */
    protected function view(string $view, $data = [], $message = null)
    {
        $viewPath = '../Application/views/' . $view . '.php';
        if (!file_exists($viewPath)) {
            throw new \Exception("View '$view' não encontrada.");
        }
        require $viewPath;
    }

    /**
     * Este método é chamado quando o método ou classe informada pelo usuário não for encontrada.
     *
     * @return void
     */
    public function pageNotFound()
    {
        $this->view('erro404');
    }
}
