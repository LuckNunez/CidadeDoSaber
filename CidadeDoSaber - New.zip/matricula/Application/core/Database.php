<?php

namespace Application\core;

use PDO;
use PDOException;

class Database extends PDO
{
    private const HOST = 'localhost';
    private const USER = 'root';
    private const PASSWORD = '';
    private const DBNAME = 'atende';

    /**
     * Configuração para:
     * - UTF8
     * - Tratamento de erros como exceções
     * - Resultados como objetos
     * - Case sensível aos nomes originais das colunas
     */
    private const OPTIONS = [
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8",
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
        PDO::ATTR_CASE => PDO::CASE_NATURAL
    ];

    /**
     * Instância única da conexão.
     */
    private static $instance;

    /**
     * Retorna a instância do PDO.
     *
     * @return PDO
     */
    public static function getInstance(): PDO
    {
        if (empty(self::$instance)) {
            try {
                self::$instance = new PDO(
                    "mysql:host=" . self::HOST . ";dbname=" . self::DBNAME,
                    self::USER,
                    self::PASSWORD,
                    self::OPTIONS
                );
            } catch (PDOException $e) {
                error_log("Erro na conexão com o banco de dados: " . $e->getMessage());
                throw new \Exception("Não foi possível conectar ao banco de dados.");
            }
        }

        return self::$instance;
    }

    /**
     * Construtor privado para evitar instâncias diretas.
     */
    private function __construct()
    {
    }

    /**
     * Previne clonagem da instância.
     */
    private function __clone()
    {
    }
}
