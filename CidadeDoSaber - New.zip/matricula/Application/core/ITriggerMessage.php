<?php

namespace Application\core;

/**
 * Interface para mensagens de gatilho, definindo tipos e comportamento esperado.
 */
interface ITriggerMessage
{
    public const ERROR = 'error';
    public const SUCCESS = 'success';
    public const WARNING = 'warning';

    /**
     * Retorna o tipo da mensagem.
     *
     * @return string Tipo da mensagem.
     */
    public function getType(): string;

    /**
     * Retorna o conteúdo da mensagem.
     *
     * @return string Conteúdo da mensagem.
     */
    public function getMessage(): string;
}
