<?php
namespace Application\core;

/**
 * Classe para criação e manipulação de mensagens padronizadas.
 */
final class Message implements ITriggerMessage
{
    /** @var string */
    private $message;

    /** @var string */
    private $type;

    /**
     * Construtor privado para criar mensagens.
     * @param string $type Tipo da mensagem.
     * @param string $message Conteúdo da mensagem.
     */
    private function __construct(string $type, string $message)
    {
        $this->type = $type;
        $this->message = $message;
    }

    /**
     * Retorna o conteúdo da mensagem.
     * @return string
     */
    public function getMessage(): string
    {
        return $this->message;
    }

    /**
     * Retorna o tipo da mensagem.
     * @return string
     */
    public function getType(): string
    {
        return $this->type;
    }

    /**
     * Cria uma mensagem de sucesso.
     * @param string $message
     * @return Message
     */
    public static function success(string $message): Message
    {
        return new self(ITriggerMessage::SUCCESS, $message);
    }

    /**
     * Cria uma mensagem de erro.
     * @param string $message
     * @return Message
     */
    public static function error(string $message): Message
    {
        return new self(ITriggerMessage::ERROR, $message);
    }

    /**
     * Cria uma mensagem de aviso.
     * @param string $message
     * @return Message
     */
    public static function warning(string $message): Message
    {
        return new self(ITriggerMessage::WARNING, $message);
    }
}
