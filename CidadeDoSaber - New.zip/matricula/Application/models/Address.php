<?php
namespace Application\models;

use Application\core\Message;
use Application\core\Model;

class Address extends Model
{
    protected static $entity = "address"; // Ajustado para um nome mais condizente

    public function all(int $limit = 30, int $offset = 0, string $columns = "*"): ?array
    {
        $columns = 'a.id, u.name as user, a.address';
        $query = "SELECT {$columns} FROM " . self::$entity . 
                 " AS a INNER JOIN users u ON u.id = a.user_id LIMIT :limit OFFSET :offset";
        $all = $this->read($query, "limit={$limit}&offset={$offset}");

        if ($this->fail() || !$all->rowCount()) {
            $this->message = Message::error("Sua consulta não retornou registros.");
            return null;
        }
        return $all->fetchAll(\PDO::FETCH_CLASS, __CLASS__);
    }
}
