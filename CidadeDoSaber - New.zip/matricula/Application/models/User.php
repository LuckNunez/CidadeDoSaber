<?php

namespace Application\core;

class Controller
{
    // Outros métodos da classe Controller

    /**
     * Redireciona para uma URL especificada.
     * @param string $url
     */
    protected function redirect(string $url)
    {
        header("Location: $url");
        exit; // Garante que nenhum código adicional seja executado
    }
}


class User extends Controller
{
    /**
     * Exibe o formulário para cadastro de um novo usuário.
     */
    public function add()
    {
        $this->view('user/add');
    }

    /**
     * Salva o novo usuário no banco de dados ou atualiza um existente.
     */
    public function save()
    {
        $data = [
            'name' => $_POST['name'] ?? '',
            'email' => $_POST['email'] ?? '',
            'password' => password_hash($_POST['password'] ?? '', PASSWORD_BCRYPT)
        ];

        // Validação básica
        if (empty($data['name']) || empty($data['email']) || empty($_POST['password'])) {
            $this->view('user/add', ['error' => 'Todos os campos são obrigatórios.']);
            return;
        }

        // Verificar se o e-mail já existe (para criação)
        $userModel = $this->model('User');
        $existingUser = $userModel->findByEmail($data['email']);
        if ($existingUser && empty($_POST['id'])) {
            $this->view('user/add', ['error' => 'Email já está em uso.']);
            return;
        }

        // Atualizar ou criar o usuário
        if (!empty($_POST['id'])) {
            $data['id'] = $_POST['id'];
            $userModel->update("users", $data, "id = :id", "id={$data['id']}");
        } else {
            $userModel->create("users", $data);
        }

        $this->redirect('/user/index');
    }

    /**
     * Lista todos os usuários cadastrados.
     */
    public function index()
    {
        $userModel = $this->model('User');
        $users = $userModel->all();
        $this->view('user/index', ['users' => $users]);
    }

    /**
     * Exibe os detalhes de um usuário.
     * @param int $id
     */
    public function show($id)
    {
        $userModel = $this->model('User');
        $user = $userModel->findById($id);

        if ($user) {
            $this->view('user/show', ['user' => $user]);
        } else {
            $this->pageNotFound();
        }
    }

    /**
     * Exibe o formulário de edição de um usuário.
     * @param int $id
     */
    public function edit($id)
    {
        $userModel = $this->model('User');
        $user = $userModel->findById($id);

        if ($user) {
            $this->view('user/edit', ['user' => $user]);
        } else {
            $this->pageNotFound();
        }
    }

    /**
     * Exclui um usuário.
     * @param int $id
     */
    public function destroy($id)
    {
        $userModel = $this->model('User');
        $userModel->delete("usuario", "cod_usuario = :cod_usuario", "cod_usuario={$id}");
        $this->redirect('/user/index');
    }

    /**
     * Exibe o formulário de login.
     */
    public function login()
    {
        $this->view('user/login');
    }

    /**
     * Processa o logout do usuário.
     */
    public function logout()
    {
        session_destroy();
        $this->redirect('/user/login');
    }
}
