<main>
  <div class="container">
    <div class="row">
      <div class="col-8 offset-2" style="margin-top:100px">

        <?php
        use Application\core\ITriggerMessage;
        use Application\core\App;
        if (!empty($message)) {
          if ($message->getType() == ITriggerMessage::SUCCESS) {
            ?>
            <div class="alert alert-success alert-dismissible" role="alert">
              <?= $message->getMessage() ?>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <?php
          }
          ?>

          <?php
          if ($message->getType() == ITriggerMessage::ERROR) {
            ?>
            <div class="alert alert-danger alert-dismissible" role="alert">
              <?= $message->getMessage() ?>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <?php
          }
        }
        ?>
        <div class="d-flex justify-content-between mb-3">
          <h2>Endereços</h2>
          <a href="<?= App::baseUrl("address/add") ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Novo
          </a>
        </div>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Usuario</th>
              <th scope="col">Endereço</th>
              <th scope="col">Ação</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($data['address'] as $address) { ?>
              <tr>
                <td><?= $address->id ?></td>
                <td><?= $address->user ?></td>
                <td><?= $address->address ?></td>
                <td>                  
                  <a href="<?= App::baseUrl("address/edit/{$address->id}") ?>" class="btn btn-secondary">
                    <i class="fas fa-edit"></i> Editar
                  </a>
                  <a href="<?= App::baseUrl("address/show/{$address->id}") ?>" class="btn btn-info">
                    <i class="fas fa-eye"></i> Visualizar
                  </a>
                  <a href="<?= App::baseUrl("address/destroy/{$address->id}") ?>" class="btn btn-danger">
                    <i class="fas fa-trash-alt"></i> Excluir
                  </a>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</main>