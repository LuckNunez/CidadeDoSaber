<?php
use Application\core\App;
?>

<div class="container">
  <div class="row justify-content-center">
    <div class="col-12 text-center mt-5">
      <img src="/assets/img/erro.png" class="img-fluid" style="max-width: 300px">
      <h1 class="mt-3">Erro!</h1>
      <p class="lead">Desculpe, ocorreu um erro inesperado.</p>
      <a href="<?= App::baseUrl("home") ?>" class="btn btn-primary mt-3">Voltar para a página inicial</a>
    </div>
  </div>
</div>
