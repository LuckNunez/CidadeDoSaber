<div class="container">
  <div class="row">
    <div class="col-8 offset-2 text-center" style="margin-top:150px">
      <h1>Construindo um simples Framework MVC com PHP</h1>
    </div>
  </div>
</div>
