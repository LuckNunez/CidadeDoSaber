<?php
// Habilitar exibição de erros
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Corrigindo o caminho para o autoload
require_once __DIR__ . '/../../core/App.php';  // Ajuste o caminho corretamente

use Application\core\App;

// Variáveis para armazenar mensagem de erro e sucesso
$erroEmail = '';
$sucessoCadastro = '';

// Verificação do e-mail no banco de dados e cadastro do usuário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Conectar ao banco de dados (ajuste a configuração conforme seu ambiente)
    try {
        $pdo = new PDO('mysql:host=localhost;dbname=atende', 'root', '');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Capturar os dados do formulário
        $nome = $_POST['name'];
        $email = $_POST['email'];
        $senha = $_POST['password']; // Senha sem criptografia

        // Inserir dados no banco de dados
        $insertQuery = $pdo->prepare("INSERT INTO usuario (nome, email, senha) VALUES (:nome, :email, :senha)");

        // Tentar executar a inserção
        try {
            $insertQuery->execute([
                'nome' => $nome,
                'email' => $email,
                'senha' => $senha
            ]);

            // Se não ocorrer erro, mensagem de sucesso
            $sucessoCadastro = "Usuário cadastrado com sucesso!";
        } catch (PDOException $e) {
            // Capturar o erro de duplicação de e-mail
            if ($e->getCode() == 23000) {
                // Código de erro de duplicação (violação de restrição)
                $erroEmail = "O e-mail informado já está cadastrado.";
            } else {
                // Qualquer outro erro de SQL
                $erroEmail = "Erro ao cadastrar usuário: " . $e->getMessage();
            }
        }
    } catch (PDOException $e) {
        // Caso haja erro na conexão com o banco de dados
        $erroEmail = "Erro ao conectar ao banco de dados: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Usuário</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .card {
            width: 100%;
            max-width: 500px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .card-header {
            background-color: #007bff;
            color: white;
            font-size: 1.5rem;
            text-align: center;
            padding: 1.5rem;
            border-radius: 10px 10px 0 0;
        }

        .form-control {
            border-radius: 10px;
            box-shadow: none;
        }

        .btn-primary {
            border-radius: 10px;
            font-weight: bold;
            padding: 12px;
        }

        .btn-secondary {
            border-radius: 10px;
            font-weight: bold;
            padding: 12px;
        }

        .card-body {
            padding: 30px;
        }

        .form-group label {
            font-weight: bold;
        }

        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }

        .btn-primary:focus, .btn-secondary:focus {
            outline: none;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }

        .text-center a {
            display: block;
            margin-top: 10px;
            text-align: center;
            color: #007bff;
        }

        .text-center a:hover {
            text-decoration: underline;
        }

        .alert {
            margin-bottom: 20px;
        }
    </style>
</head>
<body class="bg-light">

<div class="container">
    <div class="card">
        <div class="card-header">
            Cadastro de Usuário
        </div>
        <div class="card-body">
            <!-- Exibição de mensagem de erro -->
            <?php if (!empty($erroEmail)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $erroEmail; ?>
                </div>
            <?php endif; ?>

            <!-- Exibição de mensagem de sucesso -->
            <?php if (!empty($sucessoCadastro)): ?>
                <div class="alert alert-success" role="alert">
                    <?= $sucessoCadastro; ?>
                </div>
            <?php endif; ?>

            <!-- Formulário de Cadastro -->
            <form action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="POST" id="registroForm">
                <div class="form-group mb-3">
                    <label for="nome">Nome Completo</label>
                    <input type="text" name="name" class="form-control" id="nome" placeholder="Digite seu nome completo" required>
                </div>
                <div class="form-group mb-3">
                    <label for="email">Email</label>
                    <input type="email" name="email" class="form-control" id="email" placeholder="Digite seu e-mail" required>
                </div>
                <div class="form-group mb-3">
                    <label for="senha">Senha</label>
                    <input type="password" name="password" class="form-control" id="senha" placeholder="Digite sua senha" required>
                </div>
                <button type="submit" class="btn btn-primary w-100 mb-2">Cadastrar</button>
            </form>

            <div class="text-center">
                <a href="/matricula/application/views/user/index.php">Já tem uma conta? Faça login</a>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
