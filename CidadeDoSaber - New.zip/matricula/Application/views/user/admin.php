<?php
// Habilitar exibição de erros
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Iniciar sessão para verificar se o usuário está logado como administrador
session_start();

// Verificar se as variáveis de sessão estão definidas e se o usuário tem o perfil de 'admin'
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_perfil']) || $_SESSION['user_perfil'] !== 'admin') {
    header("Location: /user/login"); // Redireciona para o login se não for admin ou não estiver logado
    exit;
}

// Conectar ao banco de dados
try {
    $pdo = new PDO('mysql:host=localhost;dbname=atende', 'root', ''); // Ajuste conforme necessário
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar todos os cursos
    $stmt_cursos = $pdo->prepare("SELECT * FROM curso");
    $stmt_cursos->execute();
    $cursos = $stmt_cursos->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $erro = "Erro ao acessar o banco de dados: " . $e->getMessage();
}

// Função para excluir um usuário da matrícula
if (isset($_GET['excluir_usuario'])) {
    $usuario_id = $_GET['excluir_usuario'];
    $curso_id = $_GET['curso_id'];

    try {
        // Excluir o usuário da matrícula no curso
        $stmt_excluir = $pdo->prepare("DELETE FROM matricula WHERE cod_usuario = :cod_usuario AND cod_curso = :cod_curso");
        $stmt_excluir->execute(['cod_usuario' => $usuario_id, 'cod_curso' => $curso_id]);

        header("Location: admin.php"); // Redireciona após a exclusão
        exit;
    } catch (PDOException $e) {
        $erro = "Erro ao excluir o usuário: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Administrativo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Estilo geral */
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f8f9fa;
        }

        .navbar {
            background-color: #007bff;
        }

        .navbar-brand, .navbar-nav .nav-link {
            color: white !important;
        }

        .navbar-nav .nav-link:hover {
            color: #cce5ff !important;
        }

        .container {
            margin-top: 30px;
        }

        .card {
            border-radius: 10px;
            margin: 20px 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .table-container {
            margin-top: 30px;
        }

        .table {
            border-radius: 10px;
            overflow: hidden;
        }

        .btn-sm {
            margin-right: 5px;
        }

        .btn-info, .btn-warning, .btn-danger, .btn-success {
            border-radius: 5px;
            padding: 8px 16px;
        }

        .text-center {
            margin-bottom: 30px;
        }

        .alert {
            margin-top: 20px;
        }

        /* Responsividade */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }
        }
    </style>
</head>
<body>

<!-- Barra de navegação -->
<nav class="navbar navbar-expand-lg navbar-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Sistema de Inscrição - Admin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="/matricula/application/views/user/index.php">Sair</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container">
    <!-- Cabeçalho do Dashboard -->
    <div class="text-center">
        <h2>Dashboard Administrativo</h2>
        <p>Visão geral dos usuários matriculados nos cursos</p>
    </div>

    <!-- Exibição de Mensagens de Erro -->
    <?php if (isset($erro)): ?>
        <div class="alert alert-danger" role="alert">
            <?= $erro ?>
        </div>
    <?php endif; ?>

    <!-- Exibir Cursos e Usuários -->
    <?php foreach ($cursos as $curso): ?>
        <div class="card">
            <div class="card-body">
                <h4 class="card-title"><?= htmlspecialchars($curso['nome_curso']) ?></h4>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nome do Usuário</th>
                            <th scope="col">Data da Inscrição</th>
                            <th scope="col">Status</th>
                            <th scope="col">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Buscar usuários matriculados no curso
                        $stmt_usuarios = $pdo->prepare("SELECT u.cod_usuario, u.nome, m.data_mat, m.status FROM matricula m JOIN usuario u ON m.cod_usuario = u.cod_usuario WHERE m.cod_curso = ?");
                        $stmt_usuarios->execute([$curso['cod_curso']]);
                        $usuarios = $stmt_usuarios->fetchAll(PDO::FETCH_ASSOC);

                        if (count($usuarios) > 0):
                            foreach ($usuarios as $index => $usuario): ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td><?= htmlspecialchars($usuario['nome']) ?></td>
                                    <td><?= htmlspecialchars($usuario['data_mat']) ?></td>
                                    <td><?= htmlspecialchars($usuario['status']) ?></td>
                                    <td>
                                        <?php if (strtolower($usuario['status']) == 'documentação entregue'): ?>
                                            <a href="avaliardocument.php?usuario_id=<?= $usuario['cod_usuario'] ?>&curso_id=<?= $curso['cod_curso'] ?>" class="btn btn-info btn-sm">Avaliar Documentação</a>
                                        <?php else: ?>
                                            <a href="editar_usuario.php?usuario_id=<?= $usuario['cod_usuario'] ?>&curso_id=<?= $curso['cod_curso'] ?>" class="btn btn-warning btn-sm">Editar</a>
                                            <a href="?excluir_usuario=<?= $usuario['cod_usuario'] ?>&curso_id=<?= $curso['cod_curso'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir este usuário?')">Excluir</a>
                                            <a href="/matricula/application/views/user/prosseguir.php?usuario_id=<?= $usuario['cod_usuario'] ?>&curso_id=<?= $curso['cod_curso'] ?>" class="btn btn-success btn-sm">Prosseguir</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach;
                        else: ?>
                            <tr>
                                <td colspan="5" class="text-center">Nenhum usuário matriculado neste curso.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
