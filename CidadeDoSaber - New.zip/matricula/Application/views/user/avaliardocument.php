<?php
// Habilitar exibição de erros
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Iniciar sessão para verificar se o usuário está logado como administrador
session_start();

// Verificar se as variáveis de sessão estão definidas e se o usuário tem o perfil de 'admin'
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_perfil']) || $_SESSION['user_perfil'] !== 'admin') {
    header("Location: /user/login"); // Redireciona para o login se não for admin ou não estiver logado
    exit;
}

// Conectar ao banco de dados
try {
    $pdo = new PDO('mysql:host=localhost;dbname=atende', 'root', ''); // Ajuste conforme necessário
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verificar se o usuario_id e curso_id foram passados via GET
    if (isset($_GET['usuario_id'])) {
        $usuario_id = $_GET['usuario_id'];

        // Buscar o email do usuário (aluno) pelo usuario_id
        $stmt_email = $pdo->prepare("SELECT u.email FROM usuario u WHERE u.cod_usuario = :usuario_id");
        $stmt_email->bindParam(':usuario_id', $usuario_id);
        $stmt_email->execute();
        $usuario = $stmt_email->fetch(PDO::FETCH_ASSOC);

        if ($usuario) {
            $email_aluno = $usuario['email'];

            // Buscar os dados do aluno usando o email (sem precisar do id_aluno)
            $stmt_aluno = $pdo->prepare("SELECT u.nome, u.email, a.cpf, a.rg, a.data_nascimento, a.endereco, m.status
                                         FROM matricula m
                                         JOIN usuario u ON m.cod_usuario = u.cod_usuario
                                         JOIN aluno a ON a.email = u.email
                                         WHERE u.email = :email_aluno AND m.cod_curso = :curso_id");
            $stmt_aluno->bindParam(':email_aluno', $email_aluno);
            $stmt_aluno->bindParam(':curso_id', $_GET['curso_id']);
            $stmt_aluno->execute();
            $aluno = $stmt_aluno->fetch(PDO::FETCH_ASSOC);
        } else {
            $erro = "Usuário não encontrado.";
        }
    }

    // Alterar o status do aluno
    if (isset($_GET['alterar_status'])) {
        $novo_status = $_GET['status'];

        // Atualizar o status do aluno conforme a ação
        $stmt_alterar_status = $pdo->prepare("UPDATE matricula SET status = :status
                                              WHERE cod_usuario = :usuario_id 
                                              AND cod_curso = :curso_id");
        $stmt_alterar_status->execute([
            'status' => $novo_status,
            'usuario_id' => $usuario_id,
            'curso_id' => $_GET['curso_id']
        ]);

        // Redireciona após alterar o status para o dashboard do admin
        header("Location: admin.php");  // Aqui você vai ser redirecionado ao dashboard (admin.php)
        exit;
    }

    // Geração do HTML para exibição
    if (isset($_GET['gerar_html']) && isset($aluno)) {
        $nome = htmlspecialchars($aluno['nome']);
        $email = htmlspecialchars($aluno['email']);
        $cpf = htmlspecialchars($aluno['cpf']);
        $rg = htmlspecialchars($aluno['rg']);
        $data_nascimento = htmlspecialchars($aluno['data_nascimento']);
        $endereco = htmlspecialchars($aluno['endereco']);
        $status = htmlspecialchars($aluno['status']);

        // Gera o HTML
        $html_content = "
        <!DOCTYPE html>
        <html lang='pt-br'>
        <head>
            <meta charset='utf-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Relatório de Aluno</title>
            <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet'>
        </head>
        <body class='bg-light'>
            <div class='container mt-5'>
                <div class='text-center'>
                    <h2>Relatório de Aluno</h2>
                    <p><strong>Nome:</strong> $nome</p>
                    <p><strong>Email:</strong> $email</p>
                    <p><strong>CPF:</strong> $cpf</p>
                    <p><strong>RG:</strong> $rg</p>
                    <p><strong>Data de Nascimento:</strong> $data_nascimento</p>
                    <p><strong>Endereço:</strong> $endereco</p>
                    <p><strong>Status:</strong> $status</p>
                </div>
            </div>
        </body>
        </html>";

        // Exibir o HTML gerado
        echo $html_content;
        exit;
    }

} catch (PDOException $e) {
    $erro = "Erro ao acessar o banco de dados: " . $e->getMessage();
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Avaliar Documentação</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .table-container {
            margin-top: 30px;
        }
    </style>
</head>
<body class="bg-light">

<!-- Menu de Navegação -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Sistema de Inscrição - Admin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="/matricula/application/views/user/index.php">Sair</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <div class="text-center">
        <h2>Avaliação da Documentação</h2>
        <p>Verifique os dados do aluno e avalie a documentação.</p>
    </div>

    <!-- Exibição de Mensagens de Erro -->
    <?php if (isset($erro)): ?>
        <div class="alert alert-danger" role="alert">
            <?= $erro ?>
        </div>
    <?php endif; ?>

    <!-- Exibir Dados do Aluno -->
    <?php if (isset($aluno)): ?>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><?= htmlspecialchars($aluno['nome']) ?></h5>
                <p><strong>Email:</strong> <?= htmlspecialchars($aluno['email']) ?></p>
                <p><strong>CPF:</strong> <?= htmlspecialchars($aluno['cpf']) ?></p>
                <p><strong>RG:</strong> <?= htmlspecialchars($aluno['rg']) ?></p>
                <p><strong>Data de Nascimento:</strong> <?= htmlspecialchars($aluno['data_nascimento']) ?></p>
                <p><strong>Endereço:</strong> <?= htmlspecialchars($aluno['endereco']) ?></p>
                <p><strong>Status:</strong> <?= htmlspecialchars($aluno['status']) ?></p>

                <!-- Botões de Ação -->
                <a href="avaliardocument.php?alterar_status=true&usuario_id=<?= $usuario_id ?>&curso_id=<?= $_GET['curso_id'] ?>&status=Matriculado" class="btn btn-success">Matricular Aluno</a>
                <a href="avaliardocument.php?alterar_status=true&usuario_id=<?= $usuario_id ?>&curso_id=<?= $_GET['curso_id'] ?>&status=Documentacao Pendente" class="btn btn-danger">Documentação com Erro</a>
                <a href="admin.php" class="btn btn-secondary">Voltar</a>
                <a href="avaliardocument.php?gerar_html=true&usuario_id=<?= $usuario_id ?>&curso_id=<?= $_GET['curso_id'] ?>" class="btn btn-info">Gerar HTML</a>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-info" role="alert">
            Aluno não encontrado.
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
