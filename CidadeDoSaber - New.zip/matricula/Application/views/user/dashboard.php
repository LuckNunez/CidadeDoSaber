<?php
// Habilitar exibição de erros
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Iniciar sessão para verificar se o usuário está logado
session_start();

// Verificar se o usuário está logado, caso contrário, redireciona para a página de login
if (!isset($_SESSION['user_id'])) {
    header("Location: /user/login");
    exit;
}

use Application\core\App;

// Conectar ao banco de dados
try {
    $pdo = new PDO('mysql:host=localhost;dbname=atende', 'root', ''); // Ajuste o banco de dados conforme necessário
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar todos os cursos
    $stmt = $pdo->prepare("SELECT * FROM curso");  // Buscar cursos da tabela 'curso'
    $stmt->execute();
    $cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Verificar quantos cursos o usuário já está matriculado
    $stmt_matricula_check = $pdo->prepare("SELECT cod_curso FROM matricula WHERE cod_usuario = :cod_usuario");
    $stmt_matricula_check->execute(['cod_usuario' => $_SESSION['user_id']]);
    $cursos_matriculados = $stmt_matricula_check->fetchAll(PDO::FETCH_COLUMN);

    // Verificar o número total de cursos nos quais o usuário está matriculado
    $matriculas_count = count($cursos_matriculados);

} catch (PDOException $e) {
    $erro = "Erro ao acessar o banco de dados: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Escolher Curso</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f7fb;
            font-family: 'Roboto', sans-serif;
        }

        .navbar {
            background-color: #007bff;
        }

        .navbar-brand, .nav-link {
            color: white !important;
        }

        .navbar-brand:hover, .nav-link:hover {
            color: #f1f1f1 !important;
        }

        .course-card {
            width: 20rem;
            margin: 20px;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
        }

        .course-card:hover {
            transform: translateY(-10px);
        }

        .card-body {
            background-color: #ffffff;
            padding: 20px;
            text-align: center;
        }

        .course-card h5 {
            font-size: 1.25rem;
            font-weight: bold;
            color: #333;
        }

        .course-card p {
            font-size: 1rem;
            color: #777;
        }

        .course-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .alert {
            margin-top: 20px;
        }

        .btn {
            border-radius: 20px;
            padding: 10px 20px;
            text-align: center;
            font-size: 1rem;
        }

        .btn-primary {
            background-color: #007bff;
            border: none;
        }

        .btn-secondary {
            background-color: #ccc;
            border: none;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .btn-secondary:hover {
            background-color: #999;
        }

        .text-center h2 {
            color: #333;
            font-weight: bold;
        }

        .text-center a {
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
        }

        .text-center a:hover {
            text-decoration: underline;
        }

    </style>
</head>
<body>

<!-- Menu de Navegação -->
<nav class="navbar navbar-expand-lg navbar-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Sistema de Inscrição</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="/matricula/application/views/user/verificador.php">Verificar Inscrições</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/matricula/application/views/user/index.php">Sair</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <div class="text-center">
        <h2>Escolha um Curso</h2>
    </div>

    <div class="course-container">
        <?php if (isset($erro)): ?>
            <div class="alert alert-danger" role="alert">
                <?= $erro ?>
            </div>
        <?php endif; ?>

        <!-- Exibir os cursos em cards -->
        <?php foreach ($cursos as $curso): ?>
            <?php
                // Contar o número de matrículas para o curso atual
                $stmt_vagas = $pdo->prepare("SELECT COUNT(*) FROM matricula WHERE cod_curso = :cod_curso");
                $stmt_vagas->execute(['cod_curso' => $curso['cod_curso']]);
                $matriculas = $stmt_vagas->fetchColumn();

                // Calcular o número de vagas restantes, garantindo que não seja negativo
                $vagas_restantes = max(0, 50 - $matriculas);  // Garantir que o valor não seja negativo

                // Verificar se o usuário já está matriculado neste curso
                $matriculado = in_array($curso['cod_curso'], $cursos_matriculados);
            ?>
            <div class="card course-card">
                <div class="card-body">
                    <h5 class="card-title"><?= htmlspecialchars($curso['nome_curso']) ?></h5>

                    <!-- Exibir as vagas restantes -->
                    <p class="card-text">Vagas restantes: <?= $vagas_restantes ?></p>

                    <?php if ($matriculado): ?>
                        <button class="btn btn-secondary" disabled>Já matriculado</button>
                    <?php elseif ($matriculas_count >= 3): ?>
                        <button class="btn btn-secondary" disabled>Limite de 3 cursos atingido</button>
                    <?php elseif ($vagas_restantes > 0): ?>
                        <a href="regist_curs.php?curso_id=<?= $curso['cod_curso'] ?>" class="btn btn-primary">Inscrever</a>
                    <?php else: ?>
                        <button class="btn btn-secondary" disabled>Sem vagas</button>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Botão para sair -->
    <div class="text-center mt-3">
        <a href="/user/logout.php" class="btn btn-secondary">Sair</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
