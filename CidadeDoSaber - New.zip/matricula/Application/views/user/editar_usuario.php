<?php
// Habilitar exibição de erros
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Iniciar sessão para verificar se o usuário está logado como administrador
session_start();

// Verificar se as variáveis de sessão estão definidas e se o usuário tem o perfil de 'admin'
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_perfil']) || $_SESSION['user_perfil'] !== 'admin') {
    header("Location: /user/login"); // Redireciona para o login se não for admin ou não estiver logado
    exit;
}

try {
    $pdo = new PDO('mysql:host=localhost;dbname=atende', 'root', ''); // Ajuste conforme necessário
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verifica se o ID do usuário foi passado pela URL
    if (isset($_GET['usuario_id'])) {
        $usuario_id = $_GET['usuario_id'];

        // Buscar os dados do usuário com o ID fornecido
        $stmt = $pdo->prepare("SELECT * FROM usuario WHERE cod_usuario = ?");
        $stmt->execute([$usuario_id]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verificar se o usuário existe
        if (!$usuario) {
            throw new Exception("Usuário não encontrado.");
        }

        // Verifica se o formulário foi enviado para atualizar o nome
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $novo_nome = trim($_POST['nome']);
            if (empty($novo_nome)) {
                $erro = "O nome não pode estar vazio.";
            } else {
                // Atualizar o nome do usuário no banco de dados
                $stmt_update = $pdo->prepare("UPDATE usuario SET nome = ? WHERE cod_usuario = ?");
                $stmt_update->execute([$novo_nome, $usuario_id]);
                header("Location: admin.php"); // Redireciona para a página principal após a atualização
                exit;
            }
        }

    } else {
        throw new Exception("ID do usuário não fornecido.");
    }

} catch (PDOException $e) {
    $erro = "Erro ao acessar o banco de dados: " . $e->getMessage();
} catch (Exception $e) {
    $erro = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuário</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            padding-top: 50px;
        }
        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #545b62;
        }
        .navbar {
            margin-bottom: 20px;
        }
        .alert {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<!-- Menu de Navegação -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Sistema de Inscrição - Admin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="/matricula/application/views/user/index.php">Sair</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container">
    <div class="text-center">
        <h2>Editar Usuário</h2>
        <p>Alterar os dados do usuário conforme necessário.</p>
    </div>

    <!-- Exibição de Mensagens de Erro -->
    <?php if (isset($erro)): ?>
        <div class="alert alert-danger" role="alert">
            <?= $erro ?>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label for="nome" class="form-label">Nome do Usuário</label>
            <input type="text" class="form-control" id="nome" name="nome" value="<?= htmlspecialchars($usuario['nome']) ?>" required>
        </div>

        <!-- Botões -->
        <div class="d-flex justify-content-between">
            <button type="submit" class="btn btn-primary">Salvar Alterações</button>
            <a href="admin.php" class="btn btn-secondary">Voltar para o Dashboard</a>
        </div>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
