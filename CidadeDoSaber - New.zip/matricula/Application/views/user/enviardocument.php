<?php
session_start();

// Conectar ao banco de dados
try {
    $pdo = new PDO('mysql:host=localhost;dbname=atende', 'root', ''); // Ajuste conforme necessário
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar dados do usuário (dados adicionais)
    $stmt_usuario = $pdo->prepare("SELECT * FROM usuario WHERE cod_usuario = :cod_usuario");
    $stmt_usuario->bindParam(':cod_usuario', $_SESSION['user_id']);
    $stmt_usuario->execute();
    $usuario = $stmt_usuario->fetch(PDO::FETCH_ASSOC);

    // Buscar dados de matrícula (data_mat, etc.)
    $stmt_matricula = $pdo->prepare("SELECT data_mat FROM matricula WHERE cod_usuario = :cod_usuario");
    $stmt_matricula->bindParam(':cod_usuario', $_SESSION['user_id']);
    $stmt_matricula->execute();
    $matricula = $stmt_matricula->fetch(PDO::FETCH_ASSOC);

    // Buscar escolaridade
    $stmt_escolaridade = $pdo->query("SELECT * FROM escolaridade");
    $escolaridades = $stmt_escolaridade->fetchAll(PDO::FETCH_ASSOC);

    // Buscar escolas
    $stmt_escola = $pdo->query("SELECT * FROM escola");
    $escolas = $stmt_escola->fetchAll(PDO::FETCH_ASSOC);

    // Buscar bairros
    $stmt_bairro = $pdo->query("SELECT * FROM bairro");
    $bairros = $stmt_bairro->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $erro = "Erro ao acessar o banco de dados: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário de Cadastro Completo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            font-family: Arial, sans-serif;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
            padding-top: 20px;
        }

        .card {
            width: 100%;
            max-width: 900px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: 20px;
            padding: 30px;
            border-radius: 10px;
            background-color: white;
            max-height: 100vh;
            overflow-y: auto;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-control, .form-select {
            border-radius: 10px;
            width: 100%;
        }

        .btn-primary {
            border-radius: 10px;
            font-weight: bold;
        }

        .form-group label {
            font-weight: bold;
        }

        .conditional-field {
            display: none;
        }

        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }

        .btn-primary:focus {
            outline: none;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }
        
        .btn-voltar {
        background-color:rgb(0, 0, 0); /* Cor de fundo vermelha */
        color: white; /* Texto branco */
        font-weight: bold;
        border-radius: 50px; /* Bordas arredondadas */
        padding: 10px 20px; /* Tamanho do botão */
        text-align: center;
        display: inline-block;
        text-decoration: none;
        margin-top: 10px;
        transition: all 0.3s ease;
    }

        .btn-voltar:hover {
        background-color:rgb(255, 255, 255); /* Cor de fundo ao passar o mouse */
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Sombra para efeito de profundidade */
}

        .text-center a {
            display: block;
            margin-top: 10px;
            text-align: center;
            color:rgb(255, 255, 255);
        }

        .text-center a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body class="bg-light">

<div class="container">
    <div class="card">
        <div class="card-body">
            <h2>Formulário de Cadastro Completo</h2>

            <!-- Exibir mensagem de erro se houver -->
            <?php if (isset($erro)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $erro ?>
                </div>
            <?php endif; ?>

            <form action="submit_form.php" method="POST" id="formCadastro">

                <!-- Nome do aluno (do usuário) -->
                <div class="form-group mb-3">
                    <label for="nome_aluno">Nome do Aluno</label>
                    <input type="text" name="nome_aluno" class="form-control" id="nome_aluno" value="<?= htmlspecialchars($usuario['nome']) ?>" required>
                </div>

                <!-- Data de nascimento -->
                <div class="form-group mb-3">
                    <label for="data_nascimento">Data de Nascimento</label>
                    <input type="date" name="data_nascimento" class="form-control" id="data_nascimento" required>
                </div>

                <!-- Data de cadastro -->
                <div class="form-group mb-3">
                    <label for="data_cadastro">Data de Cadastro</label>
                    <input type="text" name="data_cadastro" class="form-control" id="data_cadastro" value="<?= htmlspecialchars($matricula['data_mat']) ?>" readonly>
                </div>

                <!-- Data de atualizado -->
                <div class="form-group mb-3">
                    <label for="data_atualizado">Data de Atualizado</label>
                    <input type="text" name="data_atualizado" class="form-control" id="data_atualizado" value="<?= date('Y-m-d H:i:s') ?>" readonly>
                </div>

                <!-- Nome do Pai -->
                <div class="form-group mb-3">
                    <label for="nome_pai">Nome do Pai</label>
                    <input type="text" name="nome_pai" class="form-control" id="nome_pai" required>
                </div>

                <!-- Nome da Mãe -->
                <div class="form-group mb-3">
                    <label for="nome_mae">Nome da Mãe</label>
                    <input type="text" name="nome_mae" class="form-control" id="nome_mae" required>
                </div>

                <!-- Sexo -->
                <div class="form-group mb-3">
                    <label for="sexo">Sexo</label>
                    <select name="sexo" id="sexo" class="form-control" required>
                        <option value="M">Masculino</option>
                        <option value="F">Feminino</option>
                    </select>
                </div>

                <!-- RG -->
                <div class="form-group mb-3">
                    <label for="rg">RG</label>
                    <input type="text" name="rg" class="form-control" id="rg" required>
                </div>

                <!-- CPF -->
                <div class="form-group mb-3">
                    <label for="cpf">CPF</label>
                    <input type="text" name="cpf" class="form-control" id="cpf" required>
                </div>

                <!-- Telefone Residencial -->
                <div class="form-group mb-3">
                    <label for="telefone_residencial">Telefone Residencial</label>
                    <input type="text" name="telefone_residencial" class="form-control" id="telefone_residencial">
                </div>

                <!-- Telefone Celular -->
                <div class="form-group mb-3">
                    <label for="telefone_celular">Telefone Celular</label>
                    <input type="text" name="telefone_celular" class="form-control" id="telefone_celular" required>
                </div>

                <!-- Email -->
                <div class="form-group mb-3">
                    <label for="email">Email</label>
                    <input type="email" name="email" class="form-control" id="email" value="<?= htmlspecialchars($usuario['email']) ?>" required>
                </div>

                <!-- Tipo Sanguíneo -->
                <div class="form-group mb-3">
                    <label for="tipo_sanguineo">Tipo Sanguíneo</label>
                    <input type="text" name="tipo_sanguineo" class="form-control" id="tipo_sanguineo">
                </div>

                <!-- Estado Civil -->
                <div class="form-group mb-3">
                    <label for="estado_civil">Estado Civil</label>
                    <input type="text" name="estado_civil" class="form-control" id="estado_civil">
                </div>

                <!-- Série Escolar -->
                <div class="form-group mb-3">
                    <label for="serie_escolar">Série Escolar</label>
                    <input type="text" name="serie_escolar" class="form-control" id="serie_escolar">
                </div>

                <!-- Turno Escolar -->
                <div class="form-group mb-3">
                    <label for="turno_escolar">Turno Escolar</label>
                    <select name="turno_escolar" id="turno_escolar" class="form-control" required>
                        <option value="M">Manhã</option>
                        <option value="T">Tarde</option>
                        <option value="N">Noite</option>
                    </select>
                </div>

                <!-- Manequim -->
                <div class="form-group mb-3">
                    <label for="manequim">Manequim</label>
                    <select name="manequim" id="manequim" class="form-control" required>
                        <option value="P">P</option>
                        <option value="M">M</option>
                        <option value="G">G</option>
                        <option value="GG">GG</option>
                        <option value="XG">XG</option>
                    </select>
                </div>

                <!-- Número do Calçado -->
                <div class="form-group mb-3">
                    <label for="numero_calcado">Número do Calçado</label>
                    <select name="numero_calcado" id="numero_calcado" class="form-control" required>
                        <option value="22">22</option>
                        <option value="23">23</option>
                        <option value="24">24</option>
                        <option value="25">25</option>
                        <option value="26">26</option>
                        <option value="27">27</option>
                        <option value="28">28</option>
                        <option value="29">29</option>
                        <option value="30">30</option>
                        <option value="31">31</option>
                        <option value="32">32</option>
                        <option value="33">33</option>
                        <option value="34">34</option>
                        <option value="35">35</option>
                        <option value="36">36</option>
                        <option value="37">37</option>
                        <option value="38">38</option>
                        <option value="39">39</option>
                        <option value="40">40</option>
                        <option value="41">41</option>
                        <option value="42">42</option>
                        <option value="43">43</option>
                        <option value="44">44</option>
                    </select>
                </div>

                <!-- Endereço -->
                <div class="form-group mb-3">
                    <label for="endereco">Endereço</label>
                    <select name="endereco" id="endereco" class="form-control" required>
                        <?php foreach ($bairros as $bairro): ?>
                            <option value="<?= $bairro['nome_bairro'] ?>"><?= $bairro['nome_bairro'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Possui Alergia -->
                <div class="form-group mb-3">
                    <label for="possui_alergia">Possui Alergia?</label>
                    <select name="possui_alergia" id="possui_alergia" class="form-control">
                        <option value="nao">Não</option>
                        <option value="sim">Sim</option>
                    </select>
                </div>

                <!-- Qual Alergia (condicional) -->
                <div class="form-group mb-3 conditional-field" id="campo_alergia">
                    <label for="qual_alergia">Qual Alergia?</label>
                    <input type="text" name="qual_alergia" class="form-control" id="qual_alergia">
                </div>

                <!-- Ex-aluno -->
                <div class="form-group mb-3">
                    <label for="ex_aluno">É ex-aluno?</label>
                    <select name="ex_aluno" id="ex_aluno" class="form-control" required>
                        <option value="nao">Não</option>
                        <option value="sim">Sim</option>
                    </select>
                </div>

                <!-- Qual Curso Fez (condicional) -->
                <div class="form-group mb-3 conditional-field" id="campo_qual_curso_fez">
                    <label for="qual_curso_fez">Qual Curso Fez</label>
                    <input type="text" name="qual_curso_fez" class="form-control" id="qual_curso_fez">
                </div>

                <!-- Outros campos -->
                <div class="form-group mb-3">
                    <label for="renda_familiar">Renda Familiar</label>
                    <input type="number" name="renda_familiar" class="form-control" id="renda_familiar" required>
                </div>

                <div class="form-group mb-3">
                    <label for="seduc">Seduc</label>
                    <input type="text" name="seduc" class="form-control" id="seduc">
                </div>

                <div class="form-group mb-3">
                    <label for="observacao">Observação</label>
                    <textarea name="observacao" class="form-control" id="observacao"></textarea>
                </div>

                <!-- Botão Voltar -->
                <a href="verificador.php" class="btn-voltar">Voltar</a>
                
                <button type="submit" class="btn btn-primary mt-4">Salvar</button>

            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Script para exibir ou esconder campos condicionalmente
    document.getElementById('possui_alergia').addEventListener('change', function() {
        var alergiaField = document.getElementById('campo_alergia');
        if (this.value === 'sim') {
            alergiaField.classList.remove('conditional-field');
        } else {
            alergiaField.classList.add('conditional-field');
        }
    });

    document.getElementById('ex_aluno').addEventListener('change', function() {
        var cursoField = document.getElementById('campo_qual_curso_fez');
        if (this.value === 'sim') {
            cursoField.classList.remove('conditional-field');
        } else {
            cursoField.classList.add('conditional-field');
        }
    });
</script>

</body>
</html>
