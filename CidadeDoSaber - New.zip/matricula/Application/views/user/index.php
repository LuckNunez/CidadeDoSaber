<?php

use Application\core\App;

// Habilitar exibição de erros
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Incluindo o arquivo App.php, caso precise de funções globais (ajustar o caminho conforme necessário)
require_once __DIR__ . '/../../core/App.php';

// Iniciar a sessão para armazenar dados de login
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Captura os dados do formulário
    $email = trim($_POST['email']);
    $senha = $_POST['password'];

    // Conectar ao banco de dados (ajuste conforme seu banco de dados)
    try {
        $pdo = new PDO('mysql:host=localhost;dbname=atende', 'root', ''); // Ajuste conforme necessário
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Consultar o banco para verificar o usuário e a senha
        $stmt = $pdo->prepare("SELECT * FROM usuario WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verificar se o usuário foi encontrado
        if ($usuario) {
            // Verificar se a senha fornecida corresponde à senha armazenada no banco
            if ($senha === $usuario['senha']) {
                // Se a senha estiver correta, armazenar as informações do usuário na sessão
                $_SESSION['user_id'] = $usuario['cod_usuario'];
                $_SESSION['user_name'] = $usuario['nome'];
                $_SESSION['user_email'] = $usuario['email'];
                $_SESSION['user_perfil'] = $usuario['perfil']; // Agora estamos salvando o perfil do usuário na sessão

                // Verificação de sucesso e redirecionamento
                if ($_SESSION['user_perfil'] === 'admin') {
                    // Redireciona para a página administrativa se for admin
                    header("Location: /matricula/application/views/user/admin.php");
                } else {
                    // Redireciona para a página padrão ou área do usuário (ajustar conforme necessário)
                    header("Location: /matricula/application/views/user/dashboard.php");
                }
                exit;
            } else {
                // Se a senha não bater, informar erro
                $erro = "Senha incorreta.";
            }
        } else {
            // Se o email não for encontrado
            $erro = "Email não encontrado.";
        }
    } catch (PDOException $e) {
        // Em caso de erro na conexão com o banco de dados
        $erro = "Erro ao acessar o banco de dados: " . $e->getMessage();
    }
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Definições gerais de estilos */
        body, html {
            height: 100%;
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('https://www.eyrc.com/img/eyrc-home-bg.jpg'); /* URL da imagem de fundo do site EYRC */
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .card {
            width: 100%;
            max-width: 400px;
            background-color: rgba(255, 255, 255, 0.8); /* Fundo semi-transparente */
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #2c3e50;
        }

        .form-control {
            border-radius: 10px;
            box-shadow: none;
            margin-bottom: 20px;
            padding: 10px;
        }

        .btn-primary {
            width: 100%;
            padding: 10px;
            border-radius: 10px;
            background-color: #007bff;
            border-color: #007bff;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #004085;
        }

        .card-body {
            padding: 0;
        }

        .form-group label {
            font-weight: 500;
            color: #34495e;
        }

        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }

        .text-center a {
            display: block;
            margin-top: 10px;
            text-align: center;
            color: #007bff;
            font-size: 14px;
        }

        .text-center a:hover {
            text-decoration: underline;
        }

        .text-danger {
            font-size: 0.9em;
            color: #e74c3c;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="card">
        <div class="card-body">
            <h2>Login</h2>

            <?php if (isset($erro)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $erro ?>
                </div>
            <?php endif; ?>

            <!-- Formulário de Login -->
            <form action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="POST" id="loginForm">
                <div class="form-group mb-3">
                    <label for="email">Email</label>
                    <input type="email" name="email" class="form-control" id="email" placeholder="Digite seu e-mail" required>
                </div>
                <div class="form-group mb-3">
                    <label for="senha">Senha</label>
                    <input type="password" name="password" class="form-control" id="senha" placeholder="Digite sua senha" required>
                </div>
                <button type="submit" class="btn btn-primary mb-3">Entrar</button>
            </form>

            <div class="text-center">
                <a href="/matricula/application/views/user/add.php">Ainda não tem uma conta? Cadastre-se</a>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
