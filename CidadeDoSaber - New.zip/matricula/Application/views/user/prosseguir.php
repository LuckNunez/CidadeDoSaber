<?php
// Habilitar exibição de erros
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Iniciar sessão para verificar se o usuário está logado como administrador
session_start();

// Verificar se as variáveis de sessão estão definidas e se o usuário tem o perfil de 'admin'
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_perfil']) || $_SESSION['user_perfil'] !== 'admin') {
    header("Location: /user/login"); // Redireciona para o login se não for admin ou não estiver logado
    exit;
}

// Conectar ao banco de dados
try {
    $pdo = new PDO('mysql:host=localhost;dbname=atende', 'root', ''); // Ajuste conforme necessário
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar dados do usuário e do curso
    if (isset($_GET['usuario_id']) && isset($_GET['curso_id'])) {
        $usuario_id = $_GET['usuario_id'];
        $curso_id = $_GET['curso_id'];

        // Buscar os dados da matrícula
        $stmt_matricula = $pdo->prepare("SELECT * FROM matricula WHERE cod_usuario = ? AND cod_curso = ?");
        $stmt_matricula->execute([$usuario_id, $curso_id]);
        $matricula = $stmt_matricula->fetch(PDO::FETCH_ASSOC);

        // Se não encontrar a matrícula, redireciona de volta
        if (!$matricula) {
            header("Location: /admin.php");
            exit;
        }

        // Buscar o nome do usuário
        $stmt_usuario = $pdo->prepare("SELECT nome FROM usuario WHERE cod_usuario = ?");
        $stmt_usuario->execute([$usuario_id]);
        $usuario = $stmt_usuario->fetch(PDO::FETCH_ASSOC);

        // Buscar o nome do curso
        $stmt_curso = $pdo->prepare("SELECT nome_curso FROM curso WHERE cod_curso = ?");
        $stmt_curso->execute([$curso_id]);
        $curso = $stmt_curso->fetch(PDO::FETCH_ASSOC);

    } else {
        header("Location: /admin.php"); // Redireciona se os parâmetros não forem passados
        exit;
    }

    // Atualizar a matrícula
    if (isset($_POST['update_matricula'])) {
        $status = $_POST['status'];

        // Atualizar os dados da matrícula
        $stmt_update = $pdo->prepare("UPDATE matricula SET status = ? WHERE cod_usuario = ? AND cod_curso = ?");
        $stmt_update->execute([$status, $usuario_id, $curso_id]);

        // Redireciona para a página administrativa após atualização
        header("Location: admin.php");
        exit;
    }

} catch (PDOException $e) {
    $erro = "Erro ao acessar o banco de dados: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prosseguir com Matrícula</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-container {
            margin-top: 30px;
        }
    </style>
</head>
<body class="bg-light">

<!-- Menu de Navegação -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Sistema de Inscrição - Admin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="/matricula/application/views/user/index.php">Sair</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container form-container">
    <h2>Gerenciar Matrícula</h2>
    
    <!-- Informações do Usuário e Curso -->
    <p><strong>Nome do Usuário:</strong> <?= htmlspecialchars($usuario['nome']) ?></p>
    <p><strong>Nome do Curso:</strong> <?= htmlspecialchars($curso['nome_curso']) ?></p>

    <!-- Exibição de Mensagens de Erro -->
    <?php if (isset($erro)): ?>
        <div class="alert alert-danger" role="alert">
            <?= $erro ?>
        </div>
    <?php endif; ?>

    <!-- Formulário de Atualização -->
    <form method="POST">
        <div class="mb-3">
            <label for="status" class="form-label">Status da Matrícula</label>
            <select class="form-select" id="status" name="status" required>
                <option value="Finalizado" <?= $matricula['status'] === 'Finalizado' ? 'selected' : '' ?>>Matriculado</option>
                <option value="Cancelado" <?= $matricula['status'] === 'Cancelado' ? 'selected' : '' ?>>Cancelado</option>
                <option value="Documentação Pendente" <?= $matricula['status'] === 'Documentação Pendente' ? 'selected' : '' ?>>Documentação Pendente</option>
            </select>
        </div>
        <button type="submit" name="update_matricula" class="btn btn-primary">Atualizar Matrícula</button>
    </form>

    <!-- Botão para Voltar para o Dashboard -->
    <a href="admin.php" class="btn btn-secondary mt-3">Voltar para o Dashboard</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
