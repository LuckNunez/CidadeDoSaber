<?php
// Habilitar exibição de erros
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Iniciar sessão para verificar se o usuário está logado
session_start();

// Verificar se o usuário está logado, caso contrário, redireciona para a página de login
if (!isset($_SESSION['user_id'])) {
    header("Location: /user/login");
    exit;
}

use Application\core\App;

try {
    // Conectar ao banco de dados
    $pdo = new PDO('mysql:host=localhost;dbname=atende', 'root', ''); // Ajuste o banco de dados conforme necessário
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verificar se um curso foi escolhido via URL
    if (isset($_GET['curso_id'])) {
        $curso_id = $_GET['curso_id'];

        // Buscar informações do curso escolhido
        $stmt_curso = $pdo->prepare("SELECT * FROM curso WHERE cod_curso = ?");
        $stmt_curso->execute([$curso_id]);
        $curso = $stmt_curso->fetch(PDO::FETCH_ASSOC);

        // Verificar se o curso existe
        if (!$curso) {
            $erro = "Curso não encontrado.";
        } else {
            // Consultar o número de matrículas existentes para o curso
            $stmt_vagas = $pdo->prepare("SELECT COUNT(*) FROM matricula WHERE cod_curso = :cod_curso");
            $stmt_vagas->execute(['cod_curso' => $curso_id]);
            $matriculas = $stmt_vagas->fetchColumn();

            // Calcular o número de vagas restantes, garantindo que não seja negativo
            $vagas_restantes = max(0, 50 - $matriculas);

            // Verificar se o formulário de inscrição foi enviado
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                // Capturar os dados do formulário
                $nome = htmlspecialchars($_POST['nome']);

                // Validar se o campo nome não está vazio
                if (empty($nome)) {
                    $erro = "O campo nome é obrigatório!";
                } else {
                    // Verificar se há vagas restantes
                    if ($vagas_restantes > 0) {
                        // Inserir inscrição no banco de dados, incluindo a data da matrícula
                        $stmt_insert = $pdo->prepare("INSERT INTO matricula (cod_curso, cod_usuario, nome, data_mat) VALUES (?, ?, ?, NOW())");
                        $stmt_insert->execute([$curso_id, $_SESSION['user_id'], $nome]);

                        // Redirecionar para a página de dashboard
                        header("Location: /matricula/application/views/user/dashboard.php");
                        exit; // Garantir que o script pare após o redirecionamento
                    } else {
                        // Mensagem de erro quando não houver vagas
                        $erro = "Não há vagas disponíveis para este curso.";
                    }
                }
            }
        }
    } else {
        $erro = "Nenhum curso foi selecionado.";
    }

} catch (PDOException $e) {
    $erro = "Erro ao acessar o banco de dados: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscrição no Curso</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .course-card {
            width: 18rem;
            margin: 15px;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .course-card .card-body {
            text-align: center;
        }
        .course-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
    </style>
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="text-center">
        <h2>Curso Escolhido: <?= htmlspecialchars($curso['nome_curso']) ?></h2>
    </div>

    <!-- Exibição de Mensagens de Sucesso ou Erro -->
    <?php if (isset($erro)): ?>
        <div class="alert alert-danger" role="alert">
            <?= $erro ?>
        </div>
    <?php elseif (isset($sucesso)): ?>
        <div class="alert alert-success" role="alert">
            <?= $sucesso ?>
        </div>
    <?php endif; ?>

    <!-- Exibir vagas restantes -->
    <div class="text-center mb-4">
        <h4>Vagas restantes: <?= $vagas_restantes ?></h4>
    </div>

    <!-- Formulário de Inscrição -->
    <form action="" method="POST">
        <div class="mb-3">
            <label for="nome" class="form-label">Nome</label>
            <input type="text" class="form-control" id="nome" name="nome" required>
        </div>
        <button type="submit" class="btn btn-primary">Inscrever</button>
    </form>

    <!-- Botão para sair -->
    <div class="text-center mt-3">
        <a href="/matricula/application/views/user/dashboard.php" class="btn btn-secondary">Sair</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
