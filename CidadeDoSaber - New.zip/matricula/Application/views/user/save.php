<?php
// Habilitar exibição de erros
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Corrigindo o caminho para o autoload
require_once __DIR__ . '/../../core/App.php';  // Ajuste o caminho corretamente

use Application\core\App;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Captura os dados do formulário
    $nome = trim($_POST['name']);
    $email = trim($_POST['email']);
    $senha = $_POST['password'];  // Senha sem criptografia

    try {
        // Conectar ao banco de dados (exemplo usando PDO)
        $pdo = new PDO('mysql:host=localhost;dbname=atende', 'root', ''); // Ajuste conforme seu banco de dados
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // SQL para inserir o usuário
        $sql = "INSERT INTO usuario (nome, email, senha) VALUES (:nome, :email, :senha)";

        // Preparar o comando
        $stmt = $pdo->prepare($sql);

        // Bind dos parâmetros
        $stmt->bindParam(':nome', $nome);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':senha', $senha);  // A senha será armazenada diretamente

        // Executar o comando
        $stmt->execute();

        // Redireciona para a página de login após o cadastro
        header("Location: " . App::baseUrl('/user/login') . "?sucesso=cadastro_realizado");
        exit;

    } catch (PDOException $e) {
        // Em caso de erro, exibe mensagem
        echo "Erro ao cadastrar usuário: " . $e->getMessage();
    }
} else {
    // Caso o método de requisição não seja POST, redireciona para o formulário
    header("Location: " . App::baseUrl('/user/add'));
    exit;
}
?>
