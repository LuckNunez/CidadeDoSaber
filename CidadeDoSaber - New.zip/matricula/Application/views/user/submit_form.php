<?php
// Iniciar sessão
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header("Location: /user/login.php"); // Redireciona para o login se não estiver logado
    exit;
}

try {
    // Conectar ao banco de dados
    $pdo = new PDO('mysql:host=localhost;dbname=atende', 'root', ''); // Ajuste conforme necessário
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verificar se o formulário foi submetido
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Obter os dados do formulário
        $nome_aluno = $_POST['nome_aluno'];
        $data_nascimento = $_POST['data_nascimento'];
        $data_cadastro = $_POST['data_cadastro'];
        $data_atualizado = $_POST['data_atualizado'];
        $nome_pai = $_POST['nome_pai'];
        $nome_mae = $_POST['nome_mae'];
        $sexo = $_POST['sexo'];
        $rg = $_POST['rg'];
        $cpf = $_POST['cpf'];
        $telefone_residencial = $_POST['telefone_residencial'];
        $telefone_celular = $_POST['telefone_celular'];
        $email = $_POST['email'];
        $tipo_sanguineo = $_POST['tipo_sanguineo'];
        $estado_civil = $_POST['estado_civil'];
        $serie_escolar = $_POST['serie_escolar'];
        $turno_escolar = $_POST['turno_escolar'];
        $manequim = $_POST['manequim'];
        $numero_calcado = $_POST['numero_calcado'];
        $endereco = $_POST['endereco'];
        $possui_alergia = $_POST['possui_alergia'];
        $qual_alergia = isset($_POST['qual_alergia']) ? $_POST['qual_alergia'] : null;
        $ex_aluno = $_POST['ex_aluno'];
        $qual_curso_fez = isset($_POST['qual_curso_fez']) ? $_POST['qual_curso_fez'] : null;
        $renda_familiar = $_POST['renda_familiar'];
        $seduc = $_POST['seduc'];
        $observacao = $_POST['observacao'];

        // Preparar e executar o insert na tabela de alunos
        $stmt = $pdo->prepare("INSERT INTO aluno (
            nome_aluno, 
            data_nascimento, 
            data_cadastro, 
            data_atualizado, 
            nome_pai, 
            nome_mae, 
            sexo, 
            rg, 
            cpf, 
            telefone_residencial, 
            telefone_celular, 
            email, 
            tipo_sanguineo, 
            estado_civil, 
            serie_escolar, 
            turno_escolar, 
            manequim, 
            numero_calcado, 
            endereco, 
            possui_alergia, 
            qual_alergia, 
            ex_aluno, 
            qual_curso_fez, 
            renda_familiar, 
            seduc, 
            obs
        ) VALUES (
            :nome_aluno, 
            :data_nascimento, 
            :data_cadastro, 
            :data_atualizado, 
            :nome_pai, 
            :nome_mae, 
            :sexo, 
            :rg, 
            :cpf, 
            :telefone_residencial, 
            :telefone_celular, 
            :email, 
            :tipo_sanguineo, 
            :estado_civil, 
            :serie_escolar, 
            :turno_escolar, 
            :manequim, 
            :numero_calcado, 
            :endereco, 
            :possui_alergia, 
            :qual_alergia, 
            :ex_aluno, 
            :qual_curso_fez, 
            :renda_familiar, 
            :seduc, 
            :observacao
        )");

        // Executar a query para inserir o aluno
        $stmt->execute([
            ':nome_aluno' => $nome_aluno,
            ':data_nascimento' => $data_nascimento,
            ':data_cadastro' => $data_cadastro,
            ':data_atualizado' => $data_atualizado,
            ':nome_pai' => $nome_pai,
            ':nome_mae' => $nome_mae,
            ':sexo' => $sexo,
            ':rg' => $rg,
            ':cpf' => $cpf,
            ':telefone_residencial' => $telefone_residencial,
            ':telefone_celular' => $telefone_celular,
            ':email' => $email,
            ':tipo_sanguineo' => $tipo_sanguineo,
            ':estado_civil' => $estado_civil,
            ':serie_escolar' => $serie_escolar,
            ':turno_escolar' => $turno_escolar,
            ':manequim' => $manequim,
            ':numero_calcado' => $numero_calcado,
            ':endereco' => $endereco,
            ':possui_alergia' => $possui_alergia,
            ':qual_alergia' => $qual_alergia,
            ':ex_aluno' => $ex_aluno,
            ':qual_curso_fez' => $qual_curso_fez,
            ':renda_familiar' => $renda_familiar,
            ':seduc' => $seduc,
            ':observacao' => $observacao
        ]);

        // Obter o ID do aluno recém inserido
        $aluno_id = $pdo->lastInsertId();

        // Verificar se existe uma matrícula para este aluno
        $stmt = $pdo->prepare("SELECT * FROM matricula WHERE cod_usuario = :cod_usuario");
        $stmt->bindParam(':cod_usuario', $aluno_id);
        $stmt->execute();
        $matricula = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($matricula) {
            // Atualizar o status da matrícula existente
            $stmt = $pdo->prepare("UPDATE matricula SET status = 'Documentação enviada' WHERE cod_usuario = :cod_usuario");
            $stmt->execute([':cod_usuario' => $aluno_id]);
        } else {
            // Caso não tenha matrícula, talvez você queira inserir uma nova matrícula
            // $stmt = $pdo->prepare("INSERT INTO matricula (cod_usuario, status) VALUES (:cod_usuario, 'Documentação pendente')");
            // $stmt->execute([':cod_usuario' => $aluno_id]);
        }

        // Redirecionar para 'verificador.php' após a inserção bem-sucedida
        header("Location: verificador.php");
        exit; // Certifique-se de que a execução do código PHP seja interrompida após o redirecionamento

    }
} catch (PDOException $e) {
    // Exibir mensagem de erro em caso de falha
    echo "Erro ao inserir dados: " . $e->getMessage();
}
?>
