<?php
// Iniciar sessão
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header("Location: /user/login.php"); // Redireciona para o login se não estiver logado
    exit;
}

// Conectar ao banco de dados
try {
    $pdo = new PDO('mysql:host=localhost;dbname=atende', 'root', ''); // Ajuste conforme necessário
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Obter o email do usuário a partir da tabela usuario
    $stmt = $pdo->prepare("SELECT email FROM usuario WHERE cod_usuario = :cod_usuario");
    $stmt->bindParam(':cod_usuario', $_SESSION['user_id']);
    $stmt->execute();
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario) {
        $email_usuario = $usuario['email'];

        // Verificar se o email está presente na tabela aluno
        $stmt = $pdo->prepare("SELECT * FROM aluno WHERE email = :email_usuario");
        $stmt->bindParam(':email_usuario', $email_usuario);
        $stmt->execute();
        $aluno = $stmt->fetch(PDO::FETCH_ASSOC);

        // Se o email do usuário for encontrado na tabela aluno, significa que a documentação foi entregue
        if ($aluno) {
            // Verificar as matrículas do usuário com o status "Documentação Pendente"
            $stmt = $pdo->prepare("SELECT status FROM matricula WHERE cod_usuario = :cod_usuario");
            $stmt->bindParam(':cod_usuario', $_SESSION['user_id']);
            $stmt->execute();
            $matricula = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($matricula && strtolower($matricula['status']) == 'documentação pendente') {
                // Atualizar o status da matrícula para "Documentação Entregue"
                $stmt = $pdo->prepare("UPDATE matricula SET status = 'Documentação Entregue' WHERE cod_usuario = :cod_usuario AND status = 'Documentação Pendente'");
                $stmt->bindParam(':cod_usuario', $_SESSION['user_id']);
                $stmt->execute();
            }
        }
    }

    // Buscar cursos em que o usuário está matriculado
    $stmt = $pdo->prepare("SELECT c.nome_curso, m.status FROM matricula m 
                            JOIN curso c ON m.cod_curso = c.cod_curso
                            WHERE m.cod_usuario = :cod_usuario");
    $stmt->bindParam(':cod_usuario', $_SESSION['user_id']);
    $stmt->execute();

    $matriculas = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Se houver um erro na consulta
    $erro = "Erro ao acessar o banco de dados: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificar Inscrição</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            font-family: Arial, sans-serif;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .card {
            width: 100%;
            max-width: 600px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .table {
            margin-top: 20px;
        }

        .status {
            font-weight: bold;
        }

        .status.pending {
            color: orange;
        }

        .status.approved {
            color: green;
        }

        .status.rejected {
            color: red;
        }

        .btn-back {
            margin-top: 20px;
            width: 100%;
        }

        .btn-enviar-document {
            margin-top: 20px;
            width: 100%;
        }
    </style>
</head>
<body class="bg-light">

<div class="container">
    <div class="card">
        <div class="card-body">
            <h2>Verificar Inscrição</h2>

            <!-- Exibir mensagem de erro se houver -->
            <?php if (isset($erro)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $erro ?>
                </div>
            <?php endif; ?>

            <!-- Exibir cursos matriculados -->
            <?php if (!empty($matriculas)): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Curso</th>
                            <th scope="col">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($matriculas as $matricula): ?>
                            <tr>
                                <td><?= htmlspecialchars($matricula['nome_curso']) ?></td>
                                <td class="status <?= strtolower($matricula['status']) ?>"><?= htmlspecialchars($matricula['status']) ?></td>
                            </tr>
                            <?php if (strtolower($matricula['status']) == 'documentação pendente'): ?>
                                <!-- Exibir o botão de enviar documentação se o status for "documentação pendente" -->
                                <tr>
                                    <td colspan="2" class="text-center">
                                        <a href="/matricula/application/views/user/enviardocument.php" target="_blank" class="btn btn-primary btn-enviar-document">
                                            Enviar Documentação
                                        </a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-info" role="alert">
                    Você ainda não está matriculado em nenhum curso.
                </div>
            <?php endif; ?>

            <!-- Botão de voltar -->
            <a href="/matricula/application/views/user/dashboard.php" class="btn btn-secondary btn-back">Voltar para os Cursos</a>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
<?php
// Iniciar sessão
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header("Location: /user/login.php"); // Redireciona para o login se não estiver logado
    exit;
}

// Conectar ao banco de dados
try {
    $pdo = new PDO('mysql:host=localhost;dbname=atende', 'root', ''); // Ajuste conforme necessário
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Obter o email do usuário a partir da tabela usuario
    $stmt = $pdo->prepare("SELECT email FROM usuario WHERE cod_usuario = :cod_usuario");
    $stmt->bindParam(':cod_usuario', $_SESSION['user_id']);
    $stmt->execute();
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario) {
        $email_usuario = $usuario['email'];

        // Verificar se o email está presente na tabela aluno
        $stmt = $pdo->prepare("SELECT * FROM aluno WHERE email = :email_usuario");
        $stmt->bindParam(':email_usuario', $email_usuario);
        $stmt->execute();
        $aluno = $stmt->fetch(PDO::FETCH_ASSOC);

        // Se o email do usuário for encontrado na tabela aluno, significa que a documentação foi entregue
        if ($aluno) {
            // Verificar as matrículas do usuário com o status "Documentação Pendente"
            $stmt = $pdo->prepare("SELECT status FROM matricula WHERE cod_usuario = :cod_usuario");
            $stmt->bindParam(':cod_usuario', $_SESSION['user_id']);
            $stmt->execute();
            $matricula = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($matricula && strtolower($matricula['status']) == 'documentação pendente') {
                // Atualizar o status da matrícula para "Documentação Entregue"
                $stmt = $pdo->prepare("UPDATE matricula SET status = 'Documentação Entregue' WHERE cod_usuario = :cod_usuario AND status = 'Documentação Pendente'");
                $stmt->bindParam(':cod_usuario', $_SESSION['user_id']);
                $stmt->execute();
            }
        }
    }

    // Buscar cursos em que o usuário está matriculado
    $stmt = $pdo->prepare("SELECT c.nome_curso, m.status FROM matricula m 
                            JOIN curso c ON m.cod_curso = c.cod_curso
                            WHERE m.cod_usuario = :cod_usuario");
    $stmt->bindParam(':cod_usuario', $_SESSION['user_id']);
    $stmt->execute();

    $matriculas = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Se houver um erro na consulta
    $erro = "Erro ao acessar o banco de dados: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificar Inscrição</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            font-family: 'Roboto', sans-serif;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            padding: 20px;
        }

        .card {
            width: 100%;
            max-width: 700px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            background-color: #fff;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        .table {
            margin-top: 20px;
        }

        .status {
            font-weight: bold;
            text-transform: capitalize;
        }

        .status.pending {
            color: #FFA500; /* Laranja */
        }

        .status.approved {
            color: #28a745; /* Verde */
        }

        .status.rejected {
            color: #dc3545; /* Vermelho */
        }

        .btn-back, .btn-enviar-document {
            width: 100%;
            margin-top: 20px;
        }

        .alert {
            margin-top: 20px;
            padding: 15px;
            border-radius: 5px;
            font-size: 16px;
        }

        .alert-info {
            background-color: #d1ecf1;
            color: #0c5460;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }
    </style>
</head>
<body class="bg-light">

<div class="container">
    <div class="card">
        <div class="card-body">
            <h2>Verificar Inscrição</h2>

            <!-- Exibir mensagem de erro se houver -->
            <?php if (isset($erro)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $erro ?>
                </div>
            <?php endif; ?>

            <!-- Exibir cursos matriculados -->
            <?php if (!empty($matriculas)): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Curso</th>
                            <th scope="col">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($matriculas as $matricula): ?>
                            <tr>
                                <td><?= htmlspecialchars($matricula['nome_curso']) ?></td>
                                <td class="status <?= strtolower($matricula['status']) ?>"><?= htmlspecialchars($matricula['status']) ?></td>
                            </tr>
                            <?php if (strtolower($matricula['status']) == 'documentação pendente'): ?>
                                <!-- Exibir o botão de enviar documentação se o status for "documentação pendente" -->
                                <tr>
                                    <td colspan="2" class="text-center">
                                        <a href="/matricula/application/views/user/enviardocument.php" target="_blank" class="btn btn-primary btn-enviar-document">
                                            Enviar Documentação
                                        </a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-info" role="alert">
                    Você ainda não está matriculado em nenhum curso.
                </div>
            <?php endif; ?>

            <!-- Botão de voltar -->
            <a href="/matricula/application/views/user/dashboard.php" class="btn btn-secondary btn-back">Voltar para os Cursos</a>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
