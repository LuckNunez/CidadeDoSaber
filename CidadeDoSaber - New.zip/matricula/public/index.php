<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Área de Acesso</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            position: relative; /* Necessário para o efeito de desfoque */
        }

        /* Aplicar o efeito de blur na imagem de fundo */
        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-image: url('http://localhost/matricula/public/assets/img/cds.jpeg');
            background-size: cover;
            background-position: center;
            filter: blur(8px); /* Efeito de desfoque */
            z-index: -1; /* Coloca a imagem atrás do conteúdo */
        }

        .acessar-container {
            width: 300px;
            height: 150px;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: rgba(255, 255, 255, 0.8); /* Cor de fundo branca e translúcida */
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5); /* Sombra mais forte */
            z-index: 1; /* Garante que o conteúdo fique acima da imagem */
        }

        .acessar-container a {
            text-decoration: none;
            color: white;
            font-size: 20px;
            font-weight: bold;
            padding: 15px 30px; /* Ajuste no tamanho do botão */
            background-color: #007BFF;
            border: 2px solid #0056b3; /* Borda sutil */
            border-radius: 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2); /* Sombras suaves */
            transition: background-color 0.3s ease, transform 0.2s ease; /* Efeito de transformação */
        }

        .acessar-container a:hover {
            background-color: #0056b3;
            transform: translateY(-3px); /* Efeito de "elevação" no hover */
        }

        .acessar-container a:active {
            transform: translateY(1px); /* Leve efeito de pressão no clique */
        }
    </style>
</head>
<body>

    <div class="acessar-container">
        <a href="http://localhost/matricula/application/views/user/index.php">Acessar</a>
    </div>

</body>
</html>
